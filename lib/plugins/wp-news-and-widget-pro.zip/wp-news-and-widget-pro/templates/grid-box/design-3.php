<?php if($newscount == "0") { ?>
	<div class="wpnews-medium-6 wpnews-columns wpnaw-left-block">
		<div class="wpnaw-news-image-bg" style="<?php echo $height_css; ?>">
			<?php if( !empty($post_featured_image) ) { ?>
				<img src="<?php echo $post_featured_image; ?>" alt="<?php _e('Post Image', 'sp-news-and-widget'); ?>" />
			<?php } ?>

			<div class="wpnaw-news-fetured-content">
				<div class="wpnaw-news-inner-content">

					<?php if($showCategory == "true" && $cate_name !='') { ?>
					<div class="wpnaw-news-categories">	
						<?php echo $cate_name; ?>
					</div>
					<?php } ?>

					<h2 class="wpnaw-news-title">
						<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
					</h2>

					<?php if($showDate == "true") { ?>
					<div class="wpnaw-news-date">
						<?php echo get_the_date(); ?>
					</div>
					<?php }
					
					if($showContent == "true") { ?>
						<div class="wpnaw-news-content">
								<div class="wpnaw-news-short-content"><?php echo wpnw_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>

								<?php if($showreadmore == 'true') { ?>
									<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
								<?php } ?>

						</div>
				<?php } ?> 

				</div>
			</div>
		</div>
	</div>
	
<?php } else {
	$wpnw_post_medium_image = wpnw_get_post_featured_image( $post->ID, 'medium', true ); // Post large image
?>
	
	<div class="wpnews-medium-6 wpnews-columns flotRight">
		<div class="wpnaw-news-right-block wpnews-medium-12 wpnews-columns">
		<?php if(!empty($wpnw_post_medium_image)) { ?>	
			<div class="wpnews-s-medium-3 wpnews-columns">
				<div class="wpnaw-news-image-bg">					
					<img src="<?php echo $wpnw_post_medium_image; ?>" alt="<?php _e('Post Image', 'sp-news-and-widget'); ?>" />				
				</div>
			</div>
			<?php } ?>

			<div class="<?php if(!empty($wpnw_post_medium_image)) { echo 'wpnews-s-medium-9 wpnews-columns'; } else { echo 'wpnews-s-medium-12 wpnews-columns'; } ?> ">
				<?php if($showCategory == "true" && $cate_name !='') { ?>
				<div class="wpnaw-news-categories">
					<?php echo $cate_name; ?>
				</div>
				<?php } ?>

				<h3 class="wpnaw-news-title">
					<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
				</h3>

				<?php if($showDate == "true") { ?>
				<div class="wpnaw-news-date">		
					<?php echo get_the_date(); ?>
				</div>
				<?php }
				if($showContent == "true") { ?>
						<div class="wpnaw-news-content">
								<div class="wpnaw-news-short-content"><?php echo wpnw_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>

								<?php if($showreadmore == 'true') { ?>
									<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
								<?php } ?>

						</div>
				<?php } ?> 
			</div>

		</div>
	</div>

<?php } ?>