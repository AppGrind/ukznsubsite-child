=== WP News and Scrolling Widgets Pro  ===
Contributors: wponlinesupport
Tags: wordpress news plugin, main news page scrolling , wordpress vertical news plugin widget, wordpress horizontal news plugin widget , Free scrolling news wordpress plugin, Free scrolling news widget wordpress plugin, WordPress set post or page as news, WordPress dynamic news, news, latest news, custom post type, cpt, widget, vertical news scrolling widget, news widget
Requires at least: 3.1
Tested up to: 4.8
Author URI: http://wponlinesupport.com

A quick, easy way to add an News custom post type, News widget to WordPress website.

== Description ==

Every CMS site needs a news section. WP News and widget pro  allows you add, manage and display news, date archives, widget on your website.

6 types of different shortcodes and 7 types of different widgets
<code>[sp_news],  [sp_news_slider], [wpnw_news_list], [wpnw_gridbox], [wpnw_gridbox_slider] and [wpnw_news_ticker]</code>

* <code>[sp_news]</code> - News Shortcode
* <code>[sp_news_slider]</code> - News Slider Shortcode
* <code>[wpnw_gridbox]</code> - News Gridbox Shortcode
* <code>[wpnw_gridbox_slider]</code> - News Gridbox Slider Shortcode
* <code>[wpnw_news_list]</code> - News List Shortcode
* <code>[wpnw_news_ticker]</code> - News Ticker Shortcode


== Installation ==

1. Upload the 'wp-news-and-widget-pro' folder to the '/wp-content/plugins/' directory.
2. Activate the WP News and widget pro plugin through the 'Plugins' menu in WordPress.
3. Add and manage news items on your site by clicking on the  'News' tab that appears in your admin menu.
4. Create a page with the any name and paste your desired short code in that.


== Changelog ==

= 1.1 (04, July 2017) =
* [+] Added new shortcode <code>[wpnw_news_list]</code> for list news layouts with 8 designs.
* [+] Added new shortcode <code>[wpnw_gridbox]</code> for GridBox news layouts with 13 designs.
* [+] Added new shortcode <code>[wpnw_gridbox_slider]</code> for GridBox news slider layouts with 8 designs.
* [+] Added Visual Composer for 3 new shortcodes.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new 20+ news designs in existing News Grid shortcode <code>[sp_news]</code>
* [+] Added new 20+ news designs in existing News Slider shortcode <code>[sp_news_slider]</code>
* [+] Added Image Fit, Media Size and Image height options in widgets.
* [+] Added 'Russian translation' (Beta) - Thanks to @Zo5m
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [*] Added prefix for the classes to avoide the conflict with other pluigns/themes
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_news_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[sp_news_slider]</code> and   and added in new shortcode <code>[wpnw_gridbox_slider]</code> as a #1, #2 and #3 respectively.

= 1.0 =
* Initial release.


== Upgrade Notice ==

= 1.1 (04, July 2017) =
* [+] Added new shortcode <code>[wpnw_news_list]</code> for list news layouts with 8 designs.
* [+] Added new shortcode <code>[wpnw_gridbox]</code> for GridBox news layouts with 13 designs.
* [+] Added new shortcode <code>[wpnw_gridbox_slider]</code> for GridBox news slider layouts with 8 designs.
* [+] Added Visual Composer for 3 new shortcodes.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new 20+ news designs in existing News Grid shortcode <code>[sp_news]</code>
* [+] Added new 20+ news designs in existing News Slider shortcode <code>[sp_news_slider]</code>
* [+] Added Image Fit, Media Size and Image height options in widgets.
* [+] Added 'Russian translation' (Beta) - Thanks to @Zo5m
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [*] Added prefix for the classes to avoide the conflict with other pluigns/themes
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_news_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[sp_news_slider]</code> and   and added in new shortcode <code>[wpnw_gridbox_slider]</code> as a #1, #2 and #3 respectively.

= 1.0 =
* Initial release.